dojo.addOnLoad(function() {
    function openVisualDiff() {
        if (dojo.byId("HEX_IDENTITY_REFERENCE")) {
          var documentId = dojo.byId("HEX_IDENTITY_REFERENCE").value;
          window.open("http://" + location.hostname + "/VisualDiffViewer/VisualDiff.jsp?id=" + documentId);
        }
    }

    dojo.query("a[title='Visual Diff']").connect("click", openVisualDiff);
});
